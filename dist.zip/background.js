import {addLinkTitleToTweets} from './content.js';

addLinkTitleToTweets();