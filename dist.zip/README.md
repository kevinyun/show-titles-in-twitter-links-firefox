# show-titles-in-twitter-links-firefox
Show titles/headlines in X (formerly Twitter) links again -- Firefox Extension.

For the Chrome Extension, see https://github.com/kevinyun/show-titles-in-twitter-links.



## Uploading to Firefox Store

Run `zip -r dist.zip *` to zip the package if you are on a Mac, then upload to Firefox Store.