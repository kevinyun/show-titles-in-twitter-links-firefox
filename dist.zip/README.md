# show-titles-in-twitter-links
Show titles/headlines in X (formerly Twitter) links again.



## Uploading to Google Chrome Store

Run `zip -r dist.zip *` to zip the package if you are on a Mac, then upload to Chrome Store.