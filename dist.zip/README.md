# show-titles-in-twitter-links
Show titles/headlines in X (formerly Twitter) links again.
